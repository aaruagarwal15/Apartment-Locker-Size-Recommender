package com.amazon.LSR.model;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
 
@Builder @NoArgsConstructor @AllArgsConstructor
public class LockerTolerance {

	@Setter
	@Getter
	private String lockerType;
	@Setter
	@Getter
	private Integer lockerSize;
	@Setter
	@Getter
	private Map<String, List<DailyTolerance>> dailyTolMap;


}
