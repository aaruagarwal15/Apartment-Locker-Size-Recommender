package com.amazon.LSR.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazon.LSR.model.Property;
import com.amazon.LSR.model.Unit;
import com.amazon.LSR.repository.PropertyRepository;
import com.amazon.LSR.repository.PropertyRepositoryImpl;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service("propertyService")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Log4j
public class PropertyServiceImpl implements PropertyService {

	@Autowired
	@Getter
	@Setter
	private PropertyRepository propertyRepository;

	@Override
	public List<Property> findSimilarProperties(int unitSize, int windowSize) {

		List<Property> similarPropertyList = new ArrayList<>();

		try {

			similarPropertyList = propertyRepository.findSimilarProperties(unitSize, windowSize);

		} catch (Exception e) {

			log.error("Not able to find Similar Properties for new property, DB exception occured", e);

		}
		return similarPropertyList;
	}

	@Override
	public void setProperty(Property property) {

		try {
			propertyRepository.setProperty(property);
		} catch (Exception e) {

			System.out.println("failed in setting the property " + property.getPropertyId() + " exception " + e);
		}
	}

	@Override
	public Property getProperty(String propertyId) {

		Property property = new Property();
		try {
			property = propertyRepository.getProperty(propertyId);

		} catch (Exception e) {

			log.error("failed to get the property from DB , DB exception occurred ", e);;
		}
		return property;
	}

	@Override
	public String setUnit(Unit unit, String propertyId) {

		String message = propertyRepository.addUnit(unit, propertyId);

		return message;
	}

	@Override
	public String removeUnit(Unit unit, String propertyId) {

		String message = propertyRepository.removeUnit(unit, propertyId);

		return message;
	}

}
