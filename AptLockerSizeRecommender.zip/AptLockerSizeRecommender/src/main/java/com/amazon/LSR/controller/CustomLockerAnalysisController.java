package com.amazon.LSR.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.amazon.LSR.Service.CustomLockerAnalysisService;
import com.amazon.LSR.model.DailyTolerance;
import com.amazon.LSR.model.DateWindow;
import com.amazon.LSR.model.LockerTolerance;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping(value = "/")
@ComponentScan("com.amazon")
@Log4j
@NoArgsConstructor
public class CustomLockerAnalysisController {

	@Autowired
	@Getter
	@Setter
	private CustomLockerAnalysisService customLockerAnalysisService;

	@RequestMapping(value = "/getAnalysis", method = RequestMethod.POST)

	public @ResponseBody List<LockerTolerance> lockerAnalysis(@RequestBody DateWindow dateWindow)
			throws ParseException {

		Date date1 = new SimpleDateFormat("dd-MM-yyyy").parse(dateWindow.getDateStart());

		Date date2 = new SimpleDateFormat("dd-MM-yyyy").parse(dateWindow.getDateEnd());

		log.info("starting locker analysis for dates "+date1+" and "+date2);

		List<LockerTolerance> lockerWiseTolerance = customLockerAnalysisService.customLockerAnalysis(date1, date2);

		return lockerWiseTolerance;
	}

}
