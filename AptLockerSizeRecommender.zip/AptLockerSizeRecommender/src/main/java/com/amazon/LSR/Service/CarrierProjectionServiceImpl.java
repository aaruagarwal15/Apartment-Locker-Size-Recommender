package com.amazon.LSR.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazon.LSR.model.Property;
import com.amazon.LSR.model.TimePackageCount;
import com.amazon.LSR.repository.CarrierDeliveryRepository;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service("carrierProjectionService")
@NoArgsConstructor
@Log4j
@Builder @AllArgsConstructor
public class CarrierProjectionServiceImpl implements CarrierProjectionService {

	@Getter
	@Setter
	private static Map<String, Long> carrierVisitFrequency = new HashMap<String, Long>();

	@Getter
	@Setter
	private static List<Property> similarPropList = new ArrayList<Property>();

	@Getter
	@Setter
	private CarrierDeliveryRepository carrierDeliveryRepository;

	@Getter
	@Setter
	private PropertyService propertyService;

	@Getter
	@Setter
	private PackageService packageService;
	@Getter
	@Setter
	private NewPropertyServiceImpl newPropertyServiceImpl;

	@Autowired
	public CarrierProjectionServiceImpl(CarrierDeliveryRepository carrierDeliveryRepository,
			PropertyService propertyService, PackageService packageService) {
		super();
		this.carrierDeliveryRepository = carrierDeliveryRepository;
		this.propertyService = propertyService;
		this.packageService = packageService;

		similarPropList = propertyService.findSimilarProperties(newPropertyServiceImpl.unitSize, 5);// hardcoded 5

		try {
			carrierVisitFrequency = carrierDeliveryRepository.getCarrierDeliveryData(similarPropList);
		} catch (Exception e) {

			log.error("Exception occured while getting carrierVisitFrequency for similar proprties" + e);

		}
	}

	private Map<String, Long> findCarrierWisePackageCount(Date d1, Date d2) {

		Map<String, Long> mapOfCarrierWisePackageCount = new HashMap<String, Long>();

		mapOfCarrierWisePackageCount = packageService.findWeekly3pPackageProjection(d1, d2, similarPropList);

		// getting count of carrier wise packages of that week to find the average.

		for (Map.Entry<String, Long> entry : mapOfCarrierWisePackageCount.entrySet()) {

			Long freq = carrierVisitFrequency.get(entry.getKey());

			Integer freq_Int = Integer.parseInt(Long.toString(freq));

			Integer total_Int = Integer.parseInt(Long.toString(entry.getValue()));

			Long average = (long) Math.round(total_Int / freq_Int);

			mapOfCarrierWisePackageCount.replace(entry.getKey(), average);

		}
		return mapOfCarrierWisePackageCount; // map of carrier wise average package count for a week(for all similar
												// properties)
	}

	@Override
	public Map<Date, List<TimePackageCount>> findWeekly3pProjection(Date d1, Date d2)

	{
		Map<Date, List<TimePackageCount>> weekly3pPackagesTimeWise = new HashMap<Date, List<TimePackageCount>>();

		Map<String, Long> mapOfAvgCarrierPackages = findCarrierWisePackageCount(d1, d2);

		Date date = d1;
		while (date.getTime() <= d2.getTime()) {

			Integer day = date.getDay();

			int size = newPropertyServiceImpl.newPropCarrierDeliveryInfo.get(day).size();

			List<TimePackageCount> listOfTimePacCount = new ArrayList<TimePackageCount>();

			for (int i = 0; i < size; i++) {

				String carrierId = newPropertyServiceImpl.newPropCarrierDeliveryInfo.get(day).get(i).getCarrierId();

				Integer hour = newPropertyServiceImpl.newPropCarrierDeliveryInfo.get(day).get(i).getHour();

				Long packageCount = 0l;
				if (mapOfAvgCarrierPackages.containsKey(carrierId) == true)
					packageCount = mapOfAvgCarrierPackages.get(carrierId);

				Integer packageCountInt = Integer.parseInt(packageCount.toString());

				TimePackageCount tpc = new TimePackageCount(hour, packageCountInt);

				listOfTimePacCount.add(tpc);
			}

			weekly3pPackagesTimeWise.put(date, listOfTimePacCount);

			Date newDate = new Date(date.getTime() + 3600 * 24 * 1000); // incrementing date by 1 day

			date = newDate;

		}

		return weekly3pPackagesTimeWise;

	}

}
