package com.amazon.LSR.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

 @NoArgsConstructor 
 @Builder @AllArgsConstructor
public class DateWindow {

	 @Getter @Setter
	private String dateStart;
	 @Getter @Setter
	private String dateEnd;
	 @Getter @Setter
	private Double tolerance;
}
