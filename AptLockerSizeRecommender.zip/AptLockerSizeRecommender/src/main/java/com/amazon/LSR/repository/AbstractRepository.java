package com.amazon.LSR.repository;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class AbstractRepository {

	private static final ThreadLocal<Session> sessionThread = new ThreadLocal<Session>();

	private static final Logger logger = Logger.getLogger(AbstractRepository.class);

	private static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

	public AbstractRepository() {

	}

	public static Session getSession() {
		Session session = (Session) sessionThread.get();

		if (session == null)// otherwise getting new session from factory.
		{
			session = sessionFactory.openSession();
			sessionThread.set(session);
		}

		return session;
	}

	public static void begin() {

		getSession().beginTransaction();

	}

	public static void commit() {
		try {
			getSession().getTransaction().commit();
		} catch (HibernateException he) {
			logger.error("Not able to commit to DB, Exception occurred ", he);;
		}
	}

	public static void rollback() {
		try {
			getSession().getTransaction().rollback();
		} catch (HibernateException he) {
			logger.error("Not able to rollback, Exception occurred ", he);;
		}

		try {
			getSession().close();
		} catch (HibernateException he) {
			logger.error("Not able to close the session , Exception occurred ", he);;
		}

		sessionThread.set(null);
	}

	public static void close() {
		getSession().close();// closing the session
		sessionThread.set(null); // setting current session to null
	}
}
