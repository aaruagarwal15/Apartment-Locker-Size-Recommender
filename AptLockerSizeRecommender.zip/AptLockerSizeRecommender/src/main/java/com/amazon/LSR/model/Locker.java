package com.amazon.LSR.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "locker_table")
@Builder @NoArgsConstructor @AllArgsConstructor
public class Locker {

	@Id
	@Column(name = "locker_id", nullable = false, unique = true)
	@Getter
	@Setter
	private Long lockerId;

	@ManyToOne
	@JoinColumn(name = "locker_type_id", nullable = false)
	@Getter
	@Setter
	private LockerType lockerType;

	@Column(name = "activation_date", nullable = false)
	@Getter
	@Setter
	private Date activationDate;

}
