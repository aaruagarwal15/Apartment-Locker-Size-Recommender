package com.amazon.LSR.repository;

import org.springframework.stereotype.Repository;

@Repository("carrierRepository")
public class CarrierRepositoryImpl {
	
	
	
}