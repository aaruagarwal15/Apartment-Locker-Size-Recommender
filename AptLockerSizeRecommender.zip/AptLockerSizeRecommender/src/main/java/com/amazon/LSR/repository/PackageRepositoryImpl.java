package com.amazon.LSR.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.TypedQuery;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.amazon.LSR.model.Package;
import com.amazon.LSR.model.PackageState;
import com.amazon.LSR.model.Property;

import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j;

@SuppressWarnings("deprecation")
@Repository("packageRepository")
@Log4j
@NoArgsConstructor
public class PackageRepositoryImpl extends AbstractRepository implements PackageRepository {

	public List<Package> findWeekly3pPackages(Date d1, Date d2, List<Property> similarPropList) {

		List<Package> ListAllWeekly3pPackages = new ArrayList<Package>();
		try {
			begin();

			TypedQuery<Package> query = getSession().createQuery("select p from Package p", Package.class);

			Set<String> simPropertySet = similarPropList.stream().map(Property::getPropertyId)
					.collect(Collectors.toSet());
			// finding the similar property IDs and putting in a set

			ListAllWeekly3pPackages = query.getResultStream()
					.filter(p -> p.getPackageState().getDateStart().getTime() >= d1.getTime()
							&& p.getPackageState().getDateStart().getTime() <= d2.getTime())
					.filter(p -> simPropertySet.contains(p.getResidentId())).collect(Collectors.toList());

			commit();

			return ListAllWeekly3pPackages;
		} catch (HibernateException he) {
			rollback();
			log.error("Excpetion in retreiving weekly package data for similar properties", he);
			System.out.println("between dates " + d1 + " and " + d2);

		}
		return ListAllWeekly3pPackages;
	}

	@SuppressWarnings("rawtypes")
	public Package getPackage(String packageId)  {
		
		Package packageObj = new Package();
		
		try {
			begin();// begining the txn from super class.
			Query q = getSession().createQuery("from Package where packageId= :packageId");
			q.setString("packageId", packageId);
			 packageObj = (Package) q.uniqueResult();
			commit();
			return packageObj;
		} catch (HibernateException he) {
			rollback();
			log.error("Excpetion in retreiving weekly package data for similar properties", he);
			System.out.println(" for packageId " + packageId);
			
		}
		return packageObj;
	}

	public Package setPackage(Package packageObj) {

		Package packageObjSave= new Package();
		try {
			begin();// begining the txn from super class.

			PackageState packageStateSave = PackageState.builder()
					.dateStart(packageObj.getPackageState().getDateStart())
					.dateStop(packageObj.getPackageState().getDateStop())
					.stateId(packageObj.getPackageState().getStateId()).build();

			 packageObjSave = Package.builder().packageId(packageObj.getPackageId())
					.trackingId(packageObj.getTrackingId()).carrierId(packageObj.getCarrierId())
					.lockerId(packageObj.getLockerId()).residentId(packageObj.getResidentId()).build();

			packageStateSave.setPackage1(packageObjSave);

			packageObjSave.setPackageState(packageStateSave); 

			getSession().saveOrUpdate(packageObjSave);

			commit();

			return packageObjSave;

		} catch (HibernateException he) {
			rollback();
			log.error("Excpetion in saving package data", he);
			System.out.println("for packageId " + packageObj.getPackageId());
		}

		return packageObjSave;
	}

}
