package com.amazon.LSR.test;

import org.apache.log4j.Logger;

public class Test5 {

	private static final Logger logger = Logger.getLogger(Test5.class);
	public static void main(String[] args) {
		
		logger.warn("this is a warning");
		
	}
}
