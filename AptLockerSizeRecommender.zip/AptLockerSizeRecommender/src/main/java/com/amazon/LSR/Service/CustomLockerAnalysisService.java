package com.amazon.LSR.Service;

import java.util.Date;
import java.util.List;

import com.amazon.LSR.model.LockerTolerance;

public interface CustomLockerAnalysisService {

	List<LockerTolerance>  customLockerAnalysis (Date dateStart, Date dateEnd);
	
	

}