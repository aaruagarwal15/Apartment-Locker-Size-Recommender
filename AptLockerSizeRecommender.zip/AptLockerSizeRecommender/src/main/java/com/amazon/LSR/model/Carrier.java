package com.amazon.LSR.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "carrier_table")
@Builder
public class Carrier {
	@Id
	
	@Column(name = "carrier_id", nullable = false, unique = true)
	@Getter @Setter
	private String carrierId;

	@Column(name = "carrier_name", nullable = false)
	@Getter @Setter
	private String carrierName;

	public Carrier(String carrierId, String carrierName) {
		super();
		this.carrierId = carrierId;

		this.carrierName = carrierName;

	}

}
