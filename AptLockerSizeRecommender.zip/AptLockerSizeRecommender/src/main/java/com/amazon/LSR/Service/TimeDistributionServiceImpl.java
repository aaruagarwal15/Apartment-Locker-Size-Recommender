package com.amazon.LSR.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazon.LSR.model.PairHourPercent;
import com.amazon.LSR.model.Property;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service("timeDistributionServiceImpl")
@Builder @Log4j @NoArgsConstructor @AllArgsConstructor
class TimeDistributionServiceImpl implements TimeDistributionService {
	@Autowired
	@Getter @Setter 
	private PackageService packageService;

	@Autowired
	@Getter @Setter
	private KMeanClusteringService kMeanClusteringService;

	@Autowired
	@Getter @Setter
	private PropertyService propertyService;


	@Override
	public Map<String, List<PairHourPercent>> getWeeklyMapOfTimeDist(Date d1, Date d2, int seedVal, int clusterSize,
			int windowSize) {

		int unitSize = NewPropertyServiceImpl.unitSize;

		List<Property> similarPropList = propertyService.findSimilarProperties(unitSize, 5);

		Map<String, List<Double>> mapOfTimeDiff = packageService.findWeeklyTimeDiffMap(d1, d2, similarPropList);

		return kMeanClusteringService.getPackTimeDistribution(mapOfTimeDiff, seedVal, clusterSize);

	}

	
}
