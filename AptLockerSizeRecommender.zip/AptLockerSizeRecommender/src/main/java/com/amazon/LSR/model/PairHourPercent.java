package com.amazon.LSR.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter @NoArgsConstructor @AllArgsConstructor
public class PairHourPercent {
	@Getter
	@Setter
	private Integer hours;
	@Getter
	@Setter
	private Double Percentage;

}