package com.amazon.LSR.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.TypedQuery;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.amazon.LSR.model.Shipment;

import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j;

@SuppressWarnings("deprecation")
@Repository("shipmentRepository")
@Log4j
@NoArgsConstructor
public class ShipmentRepositoryImpl extends AbstractRepository implements ShipmentRepository {

	@Override
	public List<Shipment> findWeeklyAmazonShipment(Date d1, Date d2, String newProperty) {

		List<Shipment> allWeeklyShipmentList = new ArrayList<Shipment>();// for new property all packages of amazom

		try {
			begin();
			TypedQuery<Shipment> query = getSession().createQuery("select s from Shipment s", Shipment.class);

			allWeeklyShipmentList = query.getResultStream().filter(
					s -> s.getDeliveryTime().getTime() >= d1.getTime() && s.getDeliveryTime().getTime() <= d2.getTime())
					.filter(s -> s.getAddressId().equalsIgnoreCase(newProperty)).collect(Collectors.toList());

			commit();

			return allWeeklyShipmentList;

		}

		catch (HibernateException he) {
			rollback();
			log.error("Excpetion in retreiving weekly package data for new property");
			System.out.println("for the week between " + d1 + " and " + d2);

		}

		return allWeeklyShipmentList;

	}

	@Override
	@SuppressWarnings("rawtypes")
	public Shipment getShipment(String shipmentId) {

		Shipment shipmentGet = new Shipment();
		try {
			begin();
			Query q = getSession().createQuery("from Shipment where shipmentId= :shipmentId");
			q.setString("shipmentId", shipmentId);
			shipmentGet = (Shipment) q.uniqueResult();
			commit();
			return shipmentGet;
		} catch (HibernateException he) {
			rollback();
			log.error("Excpetion in retriving shipment data", he);
			System.out.println("for shipmentId " + shipmentId);

		}
		return shipmentGet;
	}

	@Override
	public Shipment setShipment(Shipment shipment) {

		Shipment shipmentSave= new Shipment();
		try {
			begin();

			 shipmentSave = Shipment.builder().shipmentId(shipment.getShipmentId())
					.deliveryTime(shipment.getDeliveryTime()).addressId(shipment.getAddressId()).build();

			getSession().save(shipmentSave);
			commit();
			return shipmentSave;
		} catch (HibernateException he) {
			rollback();
			log.error("Excpetion in saving shipment data to DB", he);
			System.out.println("for shipment: " + shipment.getAddressId());
			
		}
		return shipmentSave;

	}

}