package com.amazon.LSR.model;

import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.amazon.LSR.model.LockerTolerance.LockerToleranceBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "carrier_delivery_table")
@Builder
@Getter
@Setter
@NoArgsConstructor @AllArgsConstructor
public class CarrierDelivery {

	@Id
	@Column(name = "property_carrier_id_delivery_time", nullable = false)
	@Getter
	@Setter
	private String propertyCarrierIdDeliveryTime;

	@Column(name = "propertyid", nullable = false)
	@Getter
	@Setter
	private String propertyId;

	@Column(name = "carrier_id", nullable = false)
	@Getter
	@Setter
	private String carrierId;

	@Column(name = "delivery_time", nullable = false)
	@Getter
	@Setter
	private String deliveryTime;
}
