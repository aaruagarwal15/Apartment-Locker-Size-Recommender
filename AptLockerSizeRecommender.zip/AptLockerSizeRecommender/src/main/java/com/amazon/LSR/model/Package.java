package com.amazon.LSR.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.amazon.LSR.model.LockerType.LockerTypeBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "package_table")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Package {

	@Id
	@Column(name = "package_id", nullable = false, unique = true)
	@Getter
	@Setter
	private String packageId;

	@Column(name = "tracking_id", nullable = false, unique = true)
	@Getter
	@Setter
	private String trackingId;

	@Column(name = "locker_id", nullable = false)
	@Getter
	@Setter
	private int lockerId;

	@Column(name = "carrier_id", nullable = false)
	@Getter
	@Setter
	private String carrierId;

	@Column(name = "resident_id", nullable = false)
	@Getter
	@Setter
	private String residentId;

	@OneToOne(mappedBy = "package1", cascade = CascadeType.ALL)
	@Getter
	@Setter
	private PackageState packageState;

	public double getDiffbwDates() {

		long diff = Math.abs(packageState.getDateStop().getTime() - packageState.getDateStart().getTime());

		double diffHours = (double) diff / (60 * 60 * 1000);

		return diffHours;

	}

}
