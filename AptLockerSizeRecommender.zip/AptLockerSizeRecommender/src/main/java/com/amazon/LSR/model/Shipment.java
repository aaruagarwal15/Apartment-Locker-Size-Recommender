package com.amazon.LSR.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "shipment_table")
@Builder @NoArgsConstructor @AllArgsConstructor
public class Shipment {
	@Id
	@Column(name = "shipment_id", nullable = false, unique = true)
	@Setter
	@Getter
	private String shipmentId;

	@Column(name = "delivery_time", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@Setter
	@Getter
	private Date deliveryTime;

	@Column(name = "address_id", nullable = false)
	@Setter
	@Getter
	private String addressId;

	public Integer getHoursOffShipment() {
		return getDeliveryTime().getHours();
	}

}