package com.amazon.LSR.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder @NoArgsConstructor @AllArgsConstructor
public class DailyTolerance {

	@Getter @Setter
	private Integer success;
	@Getter @Setter
	private Integer failure;
	@Getter @Setter
	private Double percentageTolerance;
	


	
}
