package com.amazon.LSR.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazon.LSR.model.DailyTolerance;
import com.amazon.LSR.model.PairHourPercent;
import com.amazon.LSR.model.TimePackageCount;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service("weeklylockerAnalysisService")
@Log4j
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WeeklyLockerAnalysisServiceImpl implements WeeklyLockerAnalysisService {

	@Autowired
	@Setter
	@Getter
	private ShipmentService shipmentService;

	@Autowired
	@Setter
	@Getter
	private CarrierProjectionService carrierProjectionService;

	@Autowired
	@Setter
	@Getter
	private TimeDistributionService timeDistributionService;

	@Override
	public List<ArrayList<DailyTolerance>> getWeeklyLockerAnalysis(Date d1, Date d2, int lockerSize) throws Exception {

		List<ArrayList<DailyTolerance>> weeklyListOfDailyTolerance = new ArrayList<ArrayList<DailyTolerance>>();

		Map<Date, List<TimePackageCount>> shipmentMap = shipmentService.findAmazonPackagesWeekly(d1, d2,
				NewPropertyServiceImpl.PropertyId);

		Map<Date, List<TimePackageCount>> projectionMap3p = carrierProjectionService.findWeekly3pProjection(d1, d2);

		Map<String, List<PairHourPercent>> timeDistMap = timeDistributionService.getWeeklyMapOfTimeDist(d1, d2, 15, 4,
				10);

		Date date = d1;

		while (date.getTime() <= d2.getTime()) {

			ArrayList<DailyTolerance> dailyToleranceList = new ArrayList<DailyTolerance>();

			Integer HourOfDay = 0;// starting from everyday 12 am...

			Integer DailyFailures = 0; // logging daily failure and success...

			Integer DailySuccess = 0; // logging daily success...

			shipmentMap.get(date).sort(new Comparator<TimePackageCount>() {
				@Override
				public int compare(TimePackageCount o1, TimePackageCount o2) {

					if (o1.getHour() < o2.getHour())
						return -1;
					else
						return 1;
				}
			});

			projectionMap3p.get(date).sort(new Comparator<TimePackageCount>() {
				@Override
				public int compare(TimePackageCount o1, TimePackageCount o2) {

					if (o1.getHour() < o2.getHour())
						return -1;
					else
						return 1;
				}
			});

			int i = 0;
			int j = 0;

			while (true) {
				if (i < shipmentMap.get(date).size() && HourOfDay == shipmentMap.get(date).get(i).getHour()) {

					Integer hour = shipmentMap.get(date).get(i).getHour();
					Integer count = shipmentMap.get(date).get(i).getPackageCount();

					if (timeDistMap.containsKey(Integer.toString(hour)) == true) {// checking if map of time
																					// distribution contains that hour.

						Integer countIn = count
								- lockerFailures(CustomLockerAnalysisServiceImpl.currentLockerSize, count, lockerSize);
						for (PairHourPercent php : timeDistMap.get(Integer.toString(hour))) {

							Long pickedUpCount = Math.round(php.getPercentage() * countIn / 100);

							Integer pickedUpCount_int = Integer.parseInt(Long.toString(pickedUpCount));

							CustomLockerAnalysisServiceImpl.priorityQ.add(new TimePackageCount(
									php.getHours() + CustomLockerAnalysisServiceImpl.timeCounter, pickedUpCount_int));

						}
					}

					else // else we can take distribution of any nearest hour from the map of time
							// distribution.

					{

						List<Integer> listOfHours = timeDistMap.entrySet().stream().map(t -> t.getKey())
								.map(h -> Integer.parseInt(h)).collect(Collectors.toList());

						Integer nearestHour = findNearest(listOfHours, hour);

						Integer countIn = count
								- lockerFailures(CustomLockerAnalysisServiceImpl.currentLockerSize, count, lockerSize);

						for (PairHourPercent php : timeDistMap.get(Integer.toString(nearestHour))) {

							Long pickedUpCount = Math.round(php.getPercentage() * countIn / 100);

							Integer pickedUpCount_int = Integer.parseInt(Long.toString(pickedUpCount));

							CustomLockerAnalysisServiceImpl.priorityQ.add(new TimePackageCount(
									php.getHours() + CustomLockerAnalysisServiceImpl.timeCounter, pickedUpCount_int));

						}
					}

					if (lockerFailures(CustomLockerAnalysisServiceImpl.currentLockerSize, count, lockerSize) == 0)
					// calculation of dailyfAILURES and success.
					{

						CustomLockerAnalysisServiceImpl.currentLockerSize = CustomLockerAnalysisServiceImpl.currentLockerSize
								+ count;
						DailySuccess = DailySuccess + count;
					} // incrementing locker size by new number of packages
					else {
						DailyFailures = DailyFailures
								+ lockerFailures(CustomLockerAnalysisServiceImpl.currentLockerSize, count, lockerSize);
						DailySuccess = DailySuccess + count
								- lockerFailures(CustomLockerAnalysisServiceImpl.currentLockerSize, count, lockerSize);
						CustomLockerAnalysisServiceImpl.currentLockerSize = lockerSize;
					}

					i++;
				}

				if (j < projectionMap3p.get(date).size() && HourOfDay == projectionMap3p.get(date).get(j).getHour()) {
					Integer hour = projectionMap3p.get(date).get(j).getHour();
					Integer count = projectionMap3p.get(date).get(j).getPackageCount();

					if (timeDistMap.containsKey(Integer.toString(hour)) == true) {// checking if map of time
																					// distribution contains that hour.
						Integer countIn = count
								- lockerFailures(CustomLockerAnalysisServiceImpl.currentLockerSize, count, lockerSize);
						for (PairHourPercent php : timeDistMap.get(Integer.toString(hour))) {
							Long pickedUpCount = Math.round(php.getPercentage() * countIn / 100);

							Integer pickedUpCount_int = Integer.parseInt(Long.toString(pickedUpCount));

							CustomLockerAnalysisServiceImpl.priorityQ.add(new TimePackageCount(
									php.getHours() + CustomLockerAnalysisServiceImpl.timeCounter, pickedUpCount_int));

						}
					} else // else we can take distribution of any nearest hour from the map of time
							// distribution.
					{
						List<Integer> listOfHours = timeDistMap.entrySet().stream().map(t -> t.getKey())
								.map(h -> Integer.parseInt(h)).collect(Collectors.toList());

						Integer nearestHour = findNearest(listOfHours, hour);

						Integer countIn = count
								- lockerFailures(CustomLockerAnalysisServiceImpl.currentLockerSize, count, lockerSize);

						for (PairHourPercent php : timeDistMap.get(Integer.toString(nearestHour))) {
							Long pickedUpCount = Math.round(php.getPercentage() * countIn / 100);

							Integer pickedUpCount_int = Integer.parseInt(Long.toString(pickedUpCount));

							CustomLockerAnalysisServiceImpl.priorityQ.add(new TimePackageCount(
									php.getHours() + CustomLockerAnalysisServiceImpl.timeCounter, pickedUpCount_int));

						}
					}

					if (lockerFailures(CustomLockerAnalysisServiceImpl.currentLockerSize, count, lockerSize) == 0) {
						CustomLockerAnalysisServiceImpl.currentLockerSize = CustomLockerAnalysisServiceImpl.currentLockerSize
								+ count;
						DailySuccess = DailySuccess + count;

					} // incrementing locker size by new number of packages
					else {
						DailyFailures = DailyFailures
								+ lockerFailures(CustomLockerAnalysisServiceImpl.currentLockerSize, count, lockerSize);
						DailySuccess = DailySuccess + count
								- lockerFailures(CustomLockerAnalysisServiceImpl.currentLockerSize, count, lockerSize);
						CustomLockerAnalysisServiceImpl.currentLockerSize = lockerSize;
					}

					j++;
				}
				System.out.println(CustomLockerAnalysisServiceImpl.timeCounter);

				while (CustomLockerAnalysisServiceImpl.priorityQ.isEmpty() == false
						&& CustomLockerAnalysisServiceImpl.timeCounter == CustomLockerAnalysisServiceImpl.priorityQ
								.peek().getHour()) {

					CustomLockerAnalysisServiceImpl.currentLockerSize = CustomLockerAnalysisServiceImpl.currentLockerSize
							- CustomLockerAnalysisServiceImpl.priorityQ.peek().getPackageCount();
					CustomLockerAnalysisServiceImpl.priorityQ.poll(); // polling Priority queue once packages are picked
																		// up.

				}

				CustomLockerAnalysisServiceImpl.timeCounter++;

				if (HourOfDay == 23) {
					break;
				} else
					HourOfDay++;
			}

			Double perentageTolerance = DailyFailures * 100.0 / (DailySuccess + DailyFailures);

			DailyTolerance dailyTolerance = DailyTolerance.builder().failure(DailyFailures).success(DailySuccess)
					.percentageTolerance(perentageTolerance).build();

			dailyToleranceList.add(dailyTolerance);

			weeklyListOfDailyTolerance.add(dailyToleranceList);

			Date newDate = new Date(date.getTime() + 3600 * 24 * 1000); // incrementing date by 1 day

			date = newDate;

		}

		return weeklyListOfDailyTolerance;
	}

	private int lockerFailures(int currentSize, int packageCount, int lockerSize) {
		if (currentSize == lockerSize) {
			return packageCount;
		} else {
			int diff = lockerSize - currentSize;
			if (packageCount > diff)
				return packageCount - diff;
			else
				return 0;

		}
	}

	private static int findNearest(List<Integer> list, int target) {
		int idx = 0;
		int dist = Math.abs(list.get(0) - target);

		for (int i = 1; i < list.size(); i++) {

			int cdist = Math.abs(list.get(i) - target);

			if (cdist < dist) {
				idx = i;
				dist = cdist;
			}
		}

		return list.get(idx);
	}

}
