package com.amazon.LSR.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.amazon.LSR.Service.PropertyService;
import com.amazon.LSR.Service.PropertyServiceImpl;
import com.amazon.LSR.model.Property;
import com.amazon.LSR.model.Unit;

@Controller
@RequestMapping(value="/")
public class PropertyController {

	@Autowired
	private PropertyService propertyService;

	public PropertyController() {
		super();
	}

	public PropertyController(PropertyService propertyService) {
		super();
		this.propertyService = propertyService;
	}

	@RequestMapping(value = "/addUnit/{property_id}", method = RequestMethod.POST)
	public @ResponseBody String addUnit(@RequestBody Unit unit, @PathVariable("property_id") String propertyId) {
		System.out.println("Starting with addition of Unit .- ID " + unit.getUnitId());

		String message = propertyService.setUnit(unit, propertyId);

		return message;
	}

	
	@RequestMapping(value = "/getProperty/{property_id}", method = RequestMethod.GET)
	public @ResponseBody Property getProperty(@PathVariable("property_id") String propertyId) {

		System.out.println("Start getEmployee. ID=" + propertyId);

		Property prop = new Property();

		try {
			prop = propertyService.getProperty(propertyId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("exception received " + e);
		}

		System.out.println("property " + prop.getPropertyId() + " " + prop.getUnitList().size());

		return prop;
	}

	

	@RequestMapping(value = "/deleteUnit/{property_id}", method = RequestMethod.PUT)
	public @ResponseBody String removeUnit(@RequestBody Unit unit, @PathVariable("property_id") String propertyId) {
		System.out.println("Starting with deletion of Unit .- ID " + unit.getUnitId());

		String message = propertyService.removeUnit(unit, propertyId);

		return message;
	}


	public void setPropertyService(PropertyService propertyService) {
		this.propertyService = propertyService;
	}

	public PropertyService getPropertyService() {
		return propertyService;
	}
	
}
