package com.amazon.LSR.repository;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.TypedQuery;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.amazon.LSR.model.Locker;
import com.amazon.LSR.model.LockerType;

import lombok.extern.log4j.Log4j;

@SuppressWarnings("deprecation")
@Repository("lockerTypeRepository")
@Log4j
public class LockerTypeRepositoryImpl extends AbstractRepository implements LockerTypeRepository {

	public LockerTypeRepositoryImpl() {
		// Default
	}

	public List<LockerType> getAllLockerTypes() {

		List<LockerType> listLockerType = new ArrayList<LockerType>();

		begin();
		try {

			TypedQuery<LockerType> query = getSession().createQuery("select l from LockerType l", LockerType.class);

			listLockerType = query.getResultStream().collect(Collectors.toList());

			listLockerType.sort(new Comparator<LockerType>() {

				@Override
				public int compare(LockerType o1, LockerType o2) {

					if (o1.getSlotSize() < o2.getSlotSize())
						return -1;
					else
						return 1;

				}
			});
			commit();
			return listLockerType;

		}

		catch (HibernateException he) {
			rollback();
			log.error("Excpetion while retreiving LockerType  data for  locker analysis", he);

		}

		return listLockerType;

	}

	@SuppressWarnings("rawtypes")
	public LockerType getLockerType(String lockerTypeId) throws Exception {

		try {
			begin();// begining the txn from super class.
			Query q = getSession().createQuery("from LockerType where lockerTypeId= :lockerTypeId");
			q.setString("lockerTypeId", lockerTypeId);
			LockerType lockerType1 = (LockerType) q.uniqueResult();
			commit();
			return lockerType1;
		} catch (HibernateException he) {
			rollback();
			log.error("Excpetion in retrieving lockerType data", he);
			System.out.println(" for lockerTypeId " + lockerTypeId);
			throw new Exception();
		}
	}

	public LockerType setLockerType(LockerType lockerType) throws Exception {

		try {
			begin();

			List<Locker> lockerList = new ArrayList<Locker>();

			LockerType lockerTypeSave = LockerType.builder().lockerTypeId(lockerType.getLockerTypeId())
					.slotSize(lockerType.getSlotSize()).build();

			for (int i = 0; i < lockerType.getLockerList().size(); i++) {

				Locker locker = new Locker();
				locker.setLockerId(lockerType.getLockerList().get(i).getLockerId());
				locker.setActivationDate(lockerType.getLockerList().get(i).getActivationDate());
				locker.setLockerType(lockerTypeSave);

				lockerList.add(locker);
			}

			lockerTypeSave.setLockerList(lockerList);

			getSession().save(lockerTypeSave);

			commit();

			return lockerTypeSave;

		} catch (HibernateException he) {
			rollback();
			log.error("Exception while saving LockerType oject to DB ", he);
			throw new Exception();
		}

	}

}
