package com.amazon.LSR.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.amazon.LSR.model.CarrierTime;

import lombok.Builder;

@Service("newPropertyService")
@Builder
public class NewPropertyServiceImpl {

	public static Map<Integer, List<CarrierTime>> newPropCarrierDeliveryInfo = new HashMap<Integer, List<CarrierTime>>();

	public static Integer unitSize = 22;

	public static String PropertyId = "karlSt";

	public NewPropertyServiceImpl() {

		// hardcoded carrier delivery time info new property fixed for every week
		List<CarrierTime> l = new ArrayList<>();

		l.add(new CarrierTime("FED", 9));
		l.add(new CarrierTime("DHL", 11));
		l.add(new CarrierTime("UPS", 13));

		newPropCarrierDeliveryInfo.put(1, l);

		List<CarrierTime> l2 = new ArrayList<>();
		l2.add(new CarrierTime("KN", 12));
		l2.add(new CarrierTime("SNCF", 14));
		l2.add(new CarrierTime("FED", 16));
		l2.add(new CarrierTime("XPO", 17));
		newPropCarrierDeliveryInfo.put(2, l2);

		List<CarrierTime> l3 = new ArrayList<>();

		l3.add(new CarrierTime("UPS", 10));
		l3.add(new CarrierTime("DHL", 15));

		NewPropertyServiceImpl.newPropCarrierDeliveryInfo.put(3, l3);

		List<CarrierTime> l4 = new ArrayList<>();
		l4.add(new CarrierTime("FED", 9));
		l4.add(new CarrierTime("XPO", 12));
		l4.add(new CarrierTime("KN", 14));

		NewPropertyServiceImpl.newPropCarrierDeliveryInfo.put(4, l4);

		List<CarrierTime> l5 = new ArrayList<>();
		l5.add(new CarrierTime("SNCF", 12));
		l5.add(new CarrierTime("UPS", 13));

		NewPropertyServiceImpl.newPropCarrierDeliveryInfo.put(5, l5);

		List<CarrierTime> l6 = new ArrayList<>();
		l6.add(new CarrierTime("FED", 10));
		l6.add(new CarrierTime("KN", 14));
		l6.add(new CarrierTime("DHL", 15));

		NewPropertyServiceImpl.newPropCarrierDeliveryInfo.put(6, l6);

		List<CarrierTime> l7 = new ArrayList<>();
		l7.add(new CarrierTime("FED", 9));
		l7.add(new CarrierTime("XPO", 16));

		NewPropertyServiceImpl.newPropCarrierDeliveryInfo.put(0, l7);
	}

}
