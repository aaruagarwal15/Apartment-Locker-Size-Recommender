package com.amazon.LSR.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.amazon.LSR.Service.PropertyService;
import com.amazon.LSR.Service.PropertyServiceImpl;
import com.amazon.LSR.model.Property;
import com.amazon.LSR.model.Unit;

public class Test4 {

	private static int findNearest(List<Integer> list, int target) {
		int idx = 0;
		int dist = Math.abs(list.get(0) - target);

		for (int i = 1; i < list.size(); i++) {

			int cdist = Math.abs(list.get(i) - target);

			if (cdist < dist) {
				idx = i;
				dist = cdist;
			}
		}

		return list.get(idx);
	}

	public static void main(String[] args) throws Exception {

		/*
		 * Map<Date, List<Integer>> map = new HashMap<>();
		 * 
		 * Date d = new Date(2020 - 1900, 4, 4, 0, 0);
		 * 
		 * Date d2 = new Date(d.getTime() + 24 * 3600 * 1000 * 6);
		 * 
		 * System.out.println(d + " , " + d2);
		 * 
		 * System.out.println(d.getYear() + 1900);
		 * 
		 * System.out.println(d.getMonth());
		 * 
		 * Date d18 = new Date(2020 - 1900, 4, 1, 9, 16); Shipment s18 = new
		 * Shipment("12363", d18, "karlSt");
		 * 
		 * // ShipmentRepository sr=new ShipmentRepositoryImpl();
		 * 
		 * System.out.println(d18); // sr.setShipment(s18);
		 * System.out.println(d18.getDay());
		 * 
		 * Integer i1 = 7; Integer i2 = 3;
		 * 
		 * Double per = i2 * 100.0 / (i1 + i2);
		 * 
		 * System.out.println(per);
		 * 
		 * List<Integer> l3= new listayList<Integer>();
		 * 
		 * l3.add(1); l3.add(4); l3.add(2); l3.add(10); l3.add(14);
		 * 
		 * System.out.println(findNearest(l3,6));
		 * 
		 * 
		 * 
		 * PropertyRepository pr= new PropertyRepositoryImpl();
		 * 
		 * Property prop= new Property();
		 * 
		 * try { prop= pr.getProperty("karlSt"); } catch (Exception e) { // TODO
		 * Auto-generated catch block System.out.println("exception received "+e); }
		 * 
		 * System.out.println("property "+prop.getPropertyId()+" "+prop.getUnitList().
		 * size());
		 * 
		 */

		// Java program to find k closest elements to a given value

		// This function prints k closest elements to x in list[].
		// n is the number of elements in list[]
		
		
		PropertyService ps= new PropertyServiceImpl();
		
	for(Property p: ps.findSimilarProperties(27, 5))
	{
		System.out.println(p.getPropertyId()+" "+p.getUnitList().size());
	}

	}

}
