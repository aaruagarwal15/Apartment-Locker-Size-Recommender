package com.amazon.LSR.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "locker_type_table")
@Builder @AllArgsConstructor @NoArgsConstructor
public class LockerType {

	@Id
	@Column(name = "locker_type_id", nullable = false, unique = true)
	@Getter @Setter
	private String lockerTypeId;

	@Column(name = "slot_size", nullable = false)
	@Getter @Setter
	private int slotSize;

	@OneToMany(mappedBy = "lockerType", cascade = CascadeType.ALL)
	@Getter @Setter
	private List<Locker> lockerList;


}
