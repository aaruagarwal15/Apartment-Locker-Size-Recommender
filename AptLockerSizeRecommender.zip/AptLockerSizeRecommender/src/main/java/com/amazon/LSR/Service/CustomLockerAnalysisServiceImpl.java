package com.amazon.LSR.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.amazon.LSR.model.DailyTolerance;
import com.amazon.LSR.model.LockerTolerance;
import com.amazon.LSR.model.LockerType;
import com.amazon.LSR.model.TimePackageCount;
import com.amazon.LSR.repository.LockerTypeRepository;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service("customLockerAnalysisService")
@Scope(value = "prototype")
@Builder
@AllArgsConstructor
@Log4j
public class CustomLockerAnalysisServiceImpl implements CustomLockerAnalysisService {

	public static Integer currentLockerSize;

	public static Integer timeCounter;

	public static PriorityQueue<TimePackageCount> priorityQ;

	@Autowired
	@Setter
	@Getter
	private WeeklyLockerAnalysisService weeklyLockerAnalysisService;
	@Autowired
	@Setter
	@Getter
	private LockerTypeRepository lockerTypeRepository;

	public CustomLockerAnalysisServiceImpl() {
		super();
		currentLockerSize = 0;
		timeCounter = 0;
		priorityQ = new PriorityQueue<TimePackageCount>(new Comparator<TimePackageCount>() {
			@Override
			public int compare(TimePackageCount o1, TimePackageCount o2) {
				if (o1.getHour() < o2.getHour())
					return -1;
				else
					return 1;
			}
		});

	}

	private Map<String, List<DailyTolerance>> customLockerAnalysisLockerWise(Date date1, Date date2, int lockerSize) {

		Map<String, List<DailyTolerance>> customMapOfDailyTol = new HashMap<String, List<DailyTolerance>>();

		Date dateStart = date1;

		while (dateStart.getTime() <= date2.getTime()) {

			Date weekEndDate = new Date(dateStart.getTime() + 24 * 3600 * 1000 * 6);// dateStart + 7 days =>date at the
																					// end of the week

			if (weekEndDate.getTime() <= date2.getTime()) {
				try {

					List<ArrayList<DailyTolerance>> listOfweeklyTol = weeklyLockerAnalysisService
							.getWeeklyLockerAnalysis(dateStart, weekEndDate, lockerSize);

					Date tempDate = dateStart;

					for (List<DailyTolerance> list : listOfweeklyTol) {

						DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
						String strDate = dateFormat.format(tempDate);

						customMapOfDailyTol.put(strDate, list);

						Date newDate = new Date(tempDate.getTime() + 3600 * 24 * 1000);

						tempDate = newDate;
					}

				} catch (Exception e) {

					log.error("Exception while getting weekly locker analysis ", e);
					System.out.println(" for locker size : " + lockerSize + " from date start " + dateStart
							+ " to date end " + weekEndDate + " " + e);
				}

			}

			else {
				try {

					List<ArrayList<DailyTolerance>> listOfweeklyTol = weeklyLockerAnalysisService
							.getWeeklyLockerAnalysis(dateStart, date2, lockerSize);

					Date tempDate = dateStart;

					for (List<DailyTolerance> list : listOfweeklyTol) {

						DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
						String strDate = dateFormat.format(tempDate);

						customMapOfDailyTol.put(strDate, list);

						Date newDate = new Date(tempDate.getTime() + 3600 * 24 * 1000);

						tempDate = newDate;
					}

				} catch (Exception e) {

					log.error("Exception while getting weekly locker analysis ", e);
					System.out.println(" for locker size : " + lockerSize + " from date start " + dateStart
							+ " to date end " + weekEndDate + " " + e);
				}

			}

			dateStart = new Date(weekEndDate.getTime() + 3600 * 24 * 1000); // increment in date by 1.

		}

		flushStaticVars();

		return customMapOfDailyTol;

	}

	@Override
	public List<LockerTolerance> customLockerAnalysis(Date dateStart, Date dateEnd) {

		List<LockerTolerance> finalAnalysisList = new ArrayList<LockerTolerance>();

		try {

			List<LockerType> listAllLockerTypes = lockerTypeRepository.getAllLockerTypes();

			for (int i = 0; i < listAllLockerTypes.size(); i++) {

				Integer lockerSize = listAllLockerTypes.get(i).getSlotSize();

				String lockerType = listAllLockerTypes.get(i).getLockerTypeId();

				LockerTolerance lockerTolerance = new LockerTolerance();

				lockerTolerance.setLockerSize(lockerSize);

				lockerTolerance.setLockerType(lockerType);

				lockerTolerance.setDailyTolMap(customLockerAnalysisLockerWise(dateStart, dateEnd, lockerSize));

				finalAnalysisList.add(lockerTolerance);

			}

		} catch (Exception e) {
			log.error("Exception while getting all types of lockers from DB ", e);
			
		}

		return finalAnalysisList;

	}

	private void flushStaticVars() {
		currentLockerSize = 0;
		timeCounter = 0;
		priorityQ.clear();
	}
}
