package com.amazon.LSR.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.TypedQuery;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.amazon.LSR.model.Property;
import com.amazon.LSR.model.Unit;

import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j;

@SuppressWarnings("deprecation")
@Repository("propertyRepository")
@Log4j
@NoArgsConstructor
public class PropertyRepositoryImpl extends AbstractRepository implements Serializable, PropertyRepository {

	private static final long serialVersionUID = 1L;

	@Override
	public List<Property> findSimilarProperties(int unitSize, int windowSize) {

		List<Property> similarPropertyList = new ArrayList<Property>();

		try {
			begin();

			TypedQuery<Property> query = getSession().createQuery("select p from Property p", Property.class);

			List<Property> list = query.getResultStream().collect(Collectors.toList());

			list.sort(new Comparator<Property>() {

				@Override
				public int compare(Property o1, Property o2) {
					if (o1.getUnitList().size() < o2.getUnitList().size())
						return -1;
					else
						return 1;
				}
			});

			similarPropertyList = findKNearestProperties(list, unitSize, windowSize, list.size());

			commit();

			return similarPropertyList;

		} catch (HibernateException he) {

			rollback();
			log.error("Excpetion in retreiving similar property data", he);

		}
		return similarPropertyList;

	}

	@Override
	@SuppressWarnings("deprecation")
	public Property getProperty(String propertyId) {

		Property property = new Property();
		try {

			begin();
			@SuppressWarnings("rawtypes")
			Query q = getSession().createQuery("from Property where propertyId= :propertyId");
			q.setString("propertyId", propertyId);
			property = (Property) q.uniqueResult();
			commit();
			return property;

		} catch (HibernateException he) {
			rollback();
			log.error("Excpetion in retreiving property data", he);
			System.out.println("for propertyID " + propertyId);

		}

		return property;
	}

	@Override
	public Property setProperty(Property property) {

		try {
			begin();

			List<Unit> unitList = new ArrayList<Unit>();

			Property propertySave = Property.builder().propertyId(property.getPropertyId())
					.propertyState(property.getPropertyState()).build();

			for (int i = 0; i < property.getUnitList().size(); i++) {

				Unit unit = new Unit();

				unit.setUnitId(property.getUnitList().get(i).getUnitId());

				unit.setAddressId(property.getUnitList().get(i).getAddressId());

				unit.setKioskId(property.getUnitList().get(i).getKioskId());

				unit.setProperty(propertySave);

				unitList.add(unit);
			}

			propertySave.setUnitList(unitList);

			getSession().save(propertySave);

			commit();

			return propertySave;

		} catch (HibernateException he) {
			rollback();
			log.error("Excpetion in saving property data ",he);
			System.out.println(" for propertyId " + property.getPropertyId());

		}
		return property;

	}

	@Override
	public String addUnit(Unit unit, String propertyId) {
		Property property = new Property();
		try {

			property = getProperty(propertyId);

			if (property.getPropertyId() == null) {
				throw new Exception();
			} else {

				begin();

				int lastInd = property.getUnitList().size();

				Integer newUnitId = Integer.parseInt(property.getUnitList().get(lastInd - 1).getUnitId()) + 1;

				unit.setUnitId(newUnitId.toString());

				unit.setProperty(property);

				unit.setKioskId(property.getUnitList().get(0).getKioskId());

				property.getUnitList().add(unit);

				getSession().update(property);

				commit();

				System.out.println("Unit added to property : " + propertyId + " unit it :  " + unit.getUnitId());
			}
		} catch (Exception e) {
			log.warn("could not found a property with this Id");
			System.out.println(" Id: " + propertyId);
			return "could not add unit make sure you have entered valid a Property ID";
		}
		return "Unit added successfully for address Id : " + unit.getAddressId();
	}

	@Override
	public String removeUnit(Unit unit, String propertyId) {

		Property property = new Property();
		try {

			property = getProperty(propertyId);

			if (property.getPropertyId() == null) {
				throw new Exception();
			}

			else {

				String addressId = null;
				String unitId = null;
				int index = 0;

				for (int i = 0; i < property.getUnitList().size(); i++) {
					if (property.getUnitList().get(i).getAddressId().equalsIgnoreCase(unit.getAddressId())) {
						unitId = property.getUnitList().get(i).getUnitId();
						addressId = unit.getAddressId();
						index = i;

						break;
					}
				}

				if (addressId == null) {

					log.warn("unit not found ");
					System.out.println("unit which is not found : " + unit.getAddressId());
					throw new Exception();
				}

				else {

					begin();

					property.getUnitList().remove(index);

					getSession().update(property);

					commit();

					System.out.println("Unit removed  : " + unit.getAddressId() + " from property : " + propertyId);
				}

			}
		} catch (Exception e) {


			log.warn("could not found a unit which you want to remove or property is invalid",e);
			
			return "Unit could not be removed please make sure you have entered valid unit id/PropertyId";
		}
		return "Unit removed";
	}

	private static int findCrossOver(List<Property> list, int low, int high, int x) {

		if (list.get(high).getUnitList().size() <= x) // x is greater than all
			return high;
		if (list.get(low).getUnitList().size() > x) // x is smaller than all
			return low;

		// Find the middle point
		int mid = (low + high) / 2;

		/* If x is same as middle element, then return mid */
		if (list.get(mid).getUnitList().size() <= x && list.get(mid + 1).getUnitList().size() > x)
			return mid;

		if (list.get(mid).getUnitList().size() < x)
			return findCrossOver(list, mid + 1, high, x);

		return findCrossOver(list, low, mid - 1, x);
	}

	private static List<Property> findKNearestProperties(List<Property> list, int x, int k, int n) {

		int l = findCrossOver(list, 0, n - 1, x);

		List<Property> similarList = new ArrayList<Property>();

		int r = l + 1;
		int count = 0;

		while (l >= 0 && r < n && count < k) {
			if (x - list.get(l).getUnitList().size() < list.get(r).getUnitList().size() - x)
				similarList.add(list.get(l--));
			else
				similarList.add(list.get(r++));
			count++;
		}

		while (count < k && l >= 0) {
			similarList.add(list.get(l--));
			count++;
		}

		while (count < k && r < n) {
			similarList.add(list.get(r++));
			count++;
		}
		return similarList;

	}
}
