package com.amazon.LSR.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "unit_table")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Unit {
	@Id
	@Column(name = "unit_id", nullable = false, unique = true)
	@Setter
	@Getter
	private String unitId;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "property_id")
	@Setter
	@Getter
	private Property property;

	@Column(name = "address_id", nullable = false)
	@Setter
	@Getter
	private String addressId;

	@Column(name = "kiosk_id", nullable = false)
	@Setter
	@Getter
	private int kioskId;

}