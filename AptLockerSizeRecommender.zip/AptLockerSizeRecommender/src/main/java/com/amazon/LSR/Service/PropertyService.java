package com.amazon.LSR.Service;

import java.util.List;

import com.amazon.LSR.model.Property;
import com.amazon.LSR.model.Unit;

public interface PropertyService {

	List<Property> findSimilarProperties(int unitSize, int windowSize);

	void setProperty(Property property);

	Property getProperty(String propertyId);

	String setUnit(Unit unit, String propertyId);

	String removeUnit(Unit unit, String propertyId);

}