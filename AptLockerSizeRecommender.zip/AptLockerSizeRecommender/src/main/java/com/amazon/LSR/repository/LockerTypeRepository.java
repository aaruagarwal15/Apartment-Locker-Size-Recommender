package com.amazon.LSR.repository;

import java.util.List;

import com.amazon.LSR.model.LockerType;

public interface LockerTypeRepository {

	LockerType getLockerType(String lockerTypeId) throws Exception;

	LockerType setLockerType(LockerType lockerType1)  throws Exception;
	
	List<LockerType> getAllLockerTypes() ;

}