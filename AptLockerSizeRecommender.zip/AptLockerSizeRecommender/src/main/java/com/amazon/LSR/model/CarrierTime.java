package com.amazon.LSR.model;

import java.util.List;
import java.util.Map;

import com.amazon.LSR.model.LockerTolerance.LockerToleranceBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CarrierTime {
	@Getter
	@Setter
	private String CarrierId;
	@Getter
	@Setter
	private Integer hour;

}
