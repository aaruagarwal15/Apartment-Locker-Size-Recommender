package com.amazon.LSR.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "property_table")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Property {

	@Id
	@Column(name = "property_id", nullable = false, unique = true)
	@Setter
	@Getter
	private String propertyId;

	@Column(name = "property_state", nullable = false)
	@Setter
	@Getter
	private String propertyState;

	@OneToMany(mappedBy = "property", cascade = CascadeType.ALL, orphanRemoval = true)
	@Setter
	@Getter
	private List<Unit> unitList;

}
