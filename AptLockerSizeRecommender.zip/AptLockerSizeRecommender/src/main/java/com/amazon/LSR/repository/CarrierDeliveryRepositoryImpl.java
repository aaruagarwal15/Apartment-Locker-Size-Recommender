package com.amazon.LSR.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.amazon.LSR.model.CarrierDelivery;
import com.amazon.LSR.model.Property;

@Repository("carrierDeliveryRepository")
public class CarrierDeliveryRepositoryImpl extends AbstractRepository implements CarrierDeliveryRepository {

	private static final Logger logger = Logger.getLogger(CarrierDeliveryRepositoryImpl.class);

	public CarrierDeliveryRepositoryImpl() {

	}

	@Override
	public Map<String, Long> getCarrierDeliveryData(List<Property> similarProperty) {

		Map<String, Long> carrierVisits = new HashMap<String, Long>();
		try {
			begin();
			TypedQuery<CarrierDelivery> query = getSession().createQuery("select cd from CarrierDelivery cd",
					CarrierDelivery.class);

			Set<String> simPropertySet = similarProperty.stream().map(Property::getPropertyId)
					.collect(Collectors.toSet());
			// getting the set of property ids from the similar property List of objects

			carrierVisits = query.getResultStream().filter(cd -> simPropertySet.contains(cd.getPropertyId()))
					.collect(Collectors.groupingBy(CarrierDelivery::getCarrierId, Collectors.counting()));

			// getting carrier wise count in a map , i.e which carrier appears how many
			// times a week time.

			commit();

			return carrierVisits;

		} catch (HibernateException he) {
			rollback();
			logger.error("Excpetion in retreiving 3p weekly visit data for similar properties", he);

		}

		return carrierVisits;

	}

	@Override
	@SuppressWarnings("rawtypes")
	public CarrierDelivery getCarrierDelivery(String propertyCarrierIdDeliveryTime) {

		CarrierDelivery propertyCarrierIdDeliveryTimeDb = new CarrierDelivery();
		try {
			begin();// begining the txn from super class.
			Query q = getSession().createQuery(
					"from CarrierDelivery where propertyCarrierIdDeliveryTime= :propertyCarrierIdDeliveryTime");
			q.setString("propertyCarrierIdDeliveryTime", propertyCarrierIdDeliveryTime);
			propertyCarrierIdDeliveryTimeDb = (CarrierDelivery) q.uniqueResult();
			commit();
			return propertyCarrierIdDeliveryTimeDb;
		} catch (HibernateException he) {
			rollback();
			logger.error("Excpetion in retriving CarrierDelivery data for PropertyCarrierIdDeliveryTime : ", he);
			System.out.println(" PropertyCarrierIdDeliveryTime :" + propertyCarrierIdDeliveryTime);

		}

		return propertyCarrierIdDeliveryTimeDb;
	}

	@Override
	public CarrierDelivery setCarrierDelivery(CarrierDelivery carrierDelivery) {

		try {
			begin();
			CarrierDelivery carrierDeliverySave = CarrierDelivery.builder()
					.propertyCarrierIdDeliveryTime(carrierDelivery.getPropertyCarrierIdDeliveryTime())
					.propertyId(carrierDelivery.getPropertyId()).carrierId(carrierDelivery.getCarrierId())
					.deliveryTime(carrierDelivery.getDeliveryTime()).build();

			getSession().save(carrierDeliverySave);

			commit();
			return carrierDeliverySave;
		} catch (HibernateException he) {
			rollback();

			logger.error("Excpetion in saving CarrierDelivery data : ", he);

			System.out
					.println(" PropertyCarrierIdDeliveryTime : " + carrierDelivery.getPropertyCarrierIdDeliveryTime());

		}
		return carrierDelivery;
	}

}
