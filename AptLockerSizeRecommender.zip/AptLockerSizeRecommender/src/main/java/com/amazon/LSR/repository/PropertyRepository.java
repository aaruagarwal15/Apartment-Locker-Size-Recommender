package com.amazon.LSR.repository;

import java.util.List;

import com.amazon.LSR.model.Property;
import com.amazon.LSR.model.Unit;

public interface PropertyRepository {

	List<Property> findSimilarProperties(int unitSize, int windowSize) ;

	Property getProperty(String propertyId) ;

	Property setProperty(Property property) ;

	String addUnit(Unit unit, String propertyId);

	String removeUnit(Unit unit, String propertyId);

}