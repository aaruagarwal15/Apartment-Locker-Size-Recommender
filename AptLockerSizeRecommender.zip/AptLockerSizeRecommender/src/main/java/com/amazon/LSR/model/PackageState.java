package com.amazon.LSR.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "package_state_table")
@Builder
@NoArgsConstructor @AllArgsConstructor
public class PackageState {

	@Id
	@Column(name = "state_id", nullable = false)
	@Setter
	@Getter
	private String stateId;

	@OneToOne
	@JoinColumn(name = "package_id")
	@Setter
	@Getter
	private Package package1;

	@Column(name = "date_start", nullable = false)
	@Setter
	@Getter
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateStart;

	@Column(name = "date_stop", nullable = false)
	@Setter
	@Getter
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateStop;

	@Column(name = "package_state", nullable = false)
	@Setter
	private String package_State;



}