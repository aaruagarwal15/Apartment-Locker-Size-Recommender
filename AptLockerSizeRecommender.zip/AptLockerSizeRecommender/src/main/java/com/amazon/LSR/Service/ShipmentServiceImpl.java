package com.amazon.LSR.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazon.LSR.model.Shipment;
import com.amazon.LSR.model.TimePackageCount;
import com.amazon.LSR.repository.ShipmentRepository;
import com.amazon.LSR.repository.ShipmentRepositoryImpl;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service("shipmentService")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Log4j
public class ShipmentServiceImpl implements ShipmentService {

	@Autowired
	@Getter
	@Setter
	private ShipmentRepository shipmentRepository;

	@Override
	public Map<Date, List<TimePackageCount>> findAmazonPackagesWeekly(Date d1, Date d2, String newPropertyId) {

		Map<Date, List<TimePackageCount>> WeeklyAmzPackages = new HashMap<Date, List<TimePackageCount>>();

		List<Shipment> listOfWeeklyShipment = shipmentRepository.findWeeklyAmazonShipment(d1, d2, newPropertyId);
		// weekly raw shipment objects list.

		Date date = d1;

		while (date.getTime() <= d2.getTime()) {

			final Date dateFinal = new Date(date.getYear(), date.getMonth(), date.getDate(), date.getHours(),
					date.getMinutes());

			List<Integer> listTimewisePackages = listOfWeeklyShipment.stream()
					.filter(s -> dateChecker(s.getDeliveryTime(), dateFinal)).map(Shipment::getHoursOffShipment)
					.collect(Collectors.toList());
			// collecting hours only from delivery time to compute packages in single hour.

			List<TimePackageCount> listOfTimePacCount = new ArrayList<TimePackageCount>();

			Map<Integer, Integer> hm = new HashMap<Integer, Integer>();

			for (Integer hour : listTimewisePackages)// timings and frequency of packages calculating using map
			{
				if (hm.containsKey(hour) == false)

					hm.put(hour, 1);

				else
					hm.replace(hour, hm.get(hour) + 1);

			}

			for (Map.Entry<Integer, Integer> entry : hm.entrySet()) {
				TimePackageCount tpc = new TimePackageCount(entry.getKey(), entry.getValue());

				listOfTimePacCount.add(tpc);
			}

			WeeklyAmzPackages.put(date, listOfTimePacCount); // putting in a map of date and list <time , no of amazon
																// packages>

			Date newDate = new Date(date.getTime() + 3600 * 24 * 1000); // incrementing date by 1 day

			date = newDate;
		}

		return WeeklyAmzPackages;

	}

	private boolean dateChecker(Date d1, Date d2) {
		if (d1.getYear() == d2.getYear()) {
			if (d1.getMonth() == d2.getMonth()) {
				if (d1.getDate() == d2.getDate())
					return true;
				else
					return false;
			} else
				return false;
		} else
			return false;
	}

}
