import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.amazon.LSR.Service.CustomLockerAnalysisService;
import com.amazon.LSR.Service.PackageService;
import com.amazon.LSR.Service.PackageServiceImpl;
import com.amazon.LSR.controller.CustomLockerAnalysisController;
import com.amazon.LSR.model.DailyTolerance;
import com.amazon.LSR.model.Locker;
import com.amazon.LSR.model.LockerTolerance;
import com.amazon.LSR.model.LockerType;
import com.amazon.LSR.repository.LockerTypeRepository;
import com.amazon.LSR.repository.PackageRepository;
import com.amazon.LSR.repository.PackageRepositoryImpl;
import com.amazon.LSR.repository.PropertyRepository;
import com.amazon.LSR.repository.PropertyRepositoryImpl;
import com.amazon.LSR.repository.AbstractRepository;

public class App {

	public static void main(String[] args) throws Exception {

		// ApplicationContext ac = new
		// AnnotationConfigApplicationContext(AppConfig.class);

		PropertyRepository pr = new PropertyRepositoryImpl();

		PackageRepository pacr = new PackageRepositoryImpl();

		PackageService ps12 = new PackageServiceImpl();

		PropertyRepository propr = new PropertyRepositoryImpl();

		ApplicationContext ac = new AnnotationConfigApplicationContext(AppConfig.class);

		CustomLockerAnalysisService cla = ac.getBean("customLockerAnalysisService", CustomLockerAnalysisService.class);

		CustomLockerAnalysisService cla2 = ac.getBean("customLockerAnalysisService", CustomLockerAnalysisService.class);

		for (LockerTolerance e : cla
				.customLockerAnalysis(new Date(2020 - 1900, 4, 11, 00, 00), new Date(2020 - 1900, 4, 20, 00, 00)))

		{
			System.out.println(e.getLockerType());
			for (Map.Entry<String,List< DailyTolerance>> e1: e.getDailyTolMap().entrySet()) {
				
				System.out.println(e1.getKey());
				
				for(DailyTolerance d: e1.getValue())
					
				{
					System.out.println(d.getSuccess()+" "+d.getFailure()+" "+d.getPercentageTolerance());
				}
			}
		}

	
		
	
	}

}
