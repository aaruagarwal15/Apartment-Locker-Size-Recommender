import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.amazon.LSR.Service.CustomLockerAnalysisService;
import com.amazon.LSR.Service.CustomLockerAnalysisServiceImpl;
import com.amazon.LSR.controller.CustomLockerAnalysisController;

@Configuration
@ComponentScan("com.amazon")
public class AppConfig {

	/*
	 * @Bean(name = "weeklyLockerAnalysisService") public
	 * WeeklyLockerAnalysisService getWeeklyLockerAnalysisService() { return new
	 * WeeklyLockerAnalysisServiceImpl(); }
	 * 
	 * 
	 * @Bean(name = "customLockerAnalysisService") public
	 * CustomLockerAnalysisService getCustomLockerAnalysisService() { return new
	 * CustomLockerAnalysisServiceImpl(getWeeklyLockerAnalysisService()); }
	 */
	/*
	 * 
	 * @Bean(name = "customLockerAnalysisController") public
	 * CustomLockerAnalysisController getCustomLockerAnalysisController() { return
	 * new CustomLockerAnalysisController(); }
	 */
	 
}
